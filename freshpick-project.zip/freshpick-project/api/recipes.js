export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { ingredients, apiKey } = req.body;

  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        max_tokens: 1500,
        messages: [{
          role: 'user',
          content: 'Du bist ein Kochassistent. Ich habe folgende Zutaten: ' + ingredients + '. Erstelle 5 Rezepte die ich damit kochen kann. Antworte NUR mit einem JSON Array, kein Text davor oder danach: [{"emoji":"🍳","name":"Rezeptname","time":20,"kcal":350,"protein":"18g","carbs":"30g","fat":"12g","match":95,"ingredients":["200g Zutat 1","2 Zutat 2"],"steps":["Schritt 1","Schritt 2","Schritt 3"]}]'
        }]
      })
    });

    const data = await response.json();
    if (!data.choices || !data.choices[0]) return res.status(500).json({ error: data.error?.message || 'API Fehler' });

    const text = data.choices[0].message.content.trim();
    const match = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (!match) return res.status(500).json({ error: 'Ungültiges Format' });

    res.status(200).json({ recipes: JSON.parse(match[0]) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
